package KASIR_RESTORAN;
public class KASIR_HARGA {
    public double byr, kembalian, kekurangan, total;
    protected int jumlah, pilihan;
    static final String selamat = "         ~> [RESTORAN NICE] <~";
    double hitungtotal (int jml){
        int harga;
        switch(pilihan){
        case 0 :
            System.exit(0);
            break;
        case 1 :
            harga = 15000;
            total = total + (harga*jumlah);
            break;
        case 2 :
            harga = 10000;
            total = total + (harga*jumlah);
            break;
        case 3 :
            harga = 20000;
            total = total + (harga*jumlah);
            break;
        case 4 :
            harga = 5000;
            total = total + (harga*jumlah);
            break;
        case 5 :
            harga = 7000;
            total = total + (harga*jumlah);
            break;
        case 6 :
            harga = 10000;
            total = total + (harga*jumlah);
            break;
        case 9 :
            break;
        default :
            System.out.println("ERROR : Input yang Anda masukkan salah");
            break;
        }
        return total;
    }
}
