package KASIR_RESTORAN;
import java.util.Scanner;
public class KASIR_MENU extends KASIR_KEMBALIAN{
    Scanner input = new Scanner (System.in);
    public KASIR_MENU (){
        System.out.println(KASIR_HARGA.selamat);
        do {
            System.out.printf("%-10s %-10s\n", "| ===== MENU ===== |","===== Harga ===== |");
            System.out.printf("%-10s %-10s\n", "| 1. Nasi Goreng  ", "| Rp. 15000         |");
            System.out.printf("%-10s %-10s\n", "| 2. Nasi Kuning  ", "| Rp. 10000         |");
            System.out.printf("%-10s %-10s\n", "| 3. Nasi Padang  ", "| Rp. 20000         |");
            System.out.printf("%-10s %-10s\n", "| 4. Es Teh       ", "| Rp. 5000          |");
            System.out.printf("%-10s %-10s\n", "| 5. Es Jeruk     ", "| Rp. 7000          |");
            System.out.printf("%-10s %-10s\n", "| 6. Es Boba      ", "| Rp. 10000         |");
            System.out.printf("%-10s %-10s\n", "| ==================","================= |");
            System.out.printf("%-10s %-10s\n", "| 9. Selesai dan Hitung Pembayaran","    |");
            System.out.printf("%-10s %-10s\n", "| 0. Keluar Program               ","    |");
            System.out.printf("%-10s %-10s\n", "| ==================","================= |");
            System.out.print("Masukkan Pilihan : ");
            pilihan = input.nextInt();
            if (pilihan >= 1 && pilihan <=6) {
                System.out.print("Masukkan Jumlah Beli : ");
                jumlah = input.nextInt();
            }
            hitungtotal(jumlah);
        } while (pilihan != 9);
        viewtotal();
        System.out.print("Bayar : Rp.");
        hitungkembalian(input.nextDouble());
        viewkembalian ();
        while (total != byr && byr < total){
            if (kekurangan != 0){
                System.out.print("Bayar : Rp.");
                pelunasan (input.nextDouble());
            }
            else {
                break;
            }
        }
    }
    public static void main(String[] args) {
        new KASIR_MENU();
    }
}
